# Packet Tools

## Validate Checksum:

### Yêu cầu:

- Yêu cầu môi trường: python3

- Yêu cầu thư viện: scapy, argparse

    ` pip install scapy`

### Sử dụng:

- Xem hướng dẫn lệnh:

    `./chksum.py -h`

- Mẫu lệnh sử dụng:

    `./chksum.py -i INPUT -o OUTPUT`
